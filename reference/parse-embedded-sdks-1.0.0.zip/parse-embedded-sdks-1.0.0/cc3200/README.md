# Parse Embedded C SDK for TI CC3200
Please refer to the [Parse CC3200 Quickstart](https://www.parse.com/apps/quickstart#embedded/ticc3200) to get started!
