var indexSectionsWithContent =
{
  0: "aciops",
  1: "p",
  2: "p",
  3: "p",
  4: "acios",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Macros",
  5: "Pages"
};

