var searchData=
[
  ['parse_20embedded_20c_20sdk',['Parse Embedded C SDK',['../index.html',1,'']]],
  ['parse_2eh',['parse.h',['../parse_8h.html',1,'']]],
  ['parseclearsessiontoken',['parseClearSessionToken',['../parse_8h.html#a32ae41797a6a551fd0311a413f94b294',1,'parse.h']]],
  ['parseclient',['ParseClient',['../parse_8h.html#ae7445d5516cd7069d413a350b3119e41',1,'parse.h']]],
  ['parsegeterrorcode',['parseGetErrorCode',['../parse_8h.html#adff0c82bf9083c1befb02c07656d5295',1,'parse.h']]],
  ['parsegetinstallationid',['parseGetInstallationId',['../parse_8h.html#aa43366546613d49321c96a46c6d5a295',1,'parse.h']]],
  ['parsegetpushsocket',['parseGetPushSocket',['../parse_8h.html#a2de71ba30eff463d9d232e2b64ec0311',1,'parse.h']]],
  ['parsegetsessiontoken',['parseGetSessionToken',['../parse_8h.html#a4c82debd7046a9b4e0da41b0573701fd',1,'parse.h']]],
  ['parseinitialize',['parseInitialize',['../parse_8h.html#aad7b0e96f115846958f4e1f2b29e6b2b',1,'parse.h']]],
  ['parseprocessnextpushnotification',['parseProcessNextPushNotification',['../parse_8h.html#a2ec677433a1b24eb26ca0250f61ae385',1,'parse.h']]],
  ['parsepushcallback',['parsePushCallback',['../parse_8h.html#afd508ae8370e6c7e8919032fcacf8d07',1,'parse.h']]],
  ['parserequestcallback',['parseRequestCallback',['../parse_8h.html#aae3c7b9a43204100f702654c2393260e',1,'parse.h']]],
  ['parserunpushloop',['parseRunPushLoop',['../parse_8h.html#a15be1ba39b90c15dc478c70f89e093c9',1,'parse.h']]],
  ['parsesendrequest',['parseSendRequest',['../parse_8h.html#af8230e72d4f6c07cb16b4675003a18fe',1,'parse.h']]],
  ['parsesetinstallationid',['parseSetInstallationId',['../parse_8h.html#ac6ec4bdc3d75d508a68662cea24010bf',1,'parse.h']]],
  ['parsesetpushcallback',['parseSetPushCallback',['../parse_8h.html#a597ea71545c6e1e6e01497edd39dcece',1,'parse.h']]],
  ['parsesetsessiontoken',['parseSetSessionToken',['../parse_8h.html#ad1a1eab66749c2ecc3f47b7f6e279679',1,'parse.h']]],
  ['parsestartpushservice',['parseStartPushService',['../parse_8h.html#aaebc5ccfcf1667a66856d75a7efc30ec',1,'parse.h']]],
  ['parsestoppushservice',['parseStopPushService',['../parse_8h.html#ac6fcdfb6a1d04f885c3de2f7c361e3f5',1,'parse.h']]]
];
