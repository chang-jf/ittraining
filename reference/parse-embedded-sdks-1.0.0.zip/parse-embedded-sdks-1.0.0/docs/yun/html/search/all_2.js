var searchData=
[
  ['clearsessiontoken',['clearSessionToken',['../class_parse_client.html#a685e9c99ec9f20b705f9899c10f64176',1,'ParseClient']]],
  ['close',['close',['../class_parse_push.html#a8cf8b847119d5ff71745f7adcaf9e505',1,'ParsePush::close()'],['../class_parse_response.html#a65132729c860ac5dae2a8b577d2baff1',1,'ParseResponse::close()']]],
  ['count',['count',['../class_parse_response.html#ac1b5565ac916af000400e6b82582ac8a',1,'ParseResponse']]]
];
