var searchData=
[
  ['orderby',['orderBy',['../class_parse_query.html#abcb70b64088699eb2b92f9d62338d08c',1,'ParseQuery']]]
];
